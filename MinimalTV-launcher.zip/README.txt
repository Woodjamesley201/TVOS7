MINIMAL TV - custom launcher for the EcoTV A (Android TV 11)

1) BUILD (no Android Studio needed)
   - Make a GitHub repo and upload everything from this zip (keep the .github folder).
   - Actions tab > "Build APK" > Run workflow > download "MinimalTV-apk" > unzip > app-debug.apk
   - Preview the look on any device: open app/src/main/assets/index.html in a browser (demo apps).

2) INSTALL
   - TV: Settings > Device Preferences > About > tap "Build" 7 times.
     Then Developer options > turn on USB debugging (and Wireless debugging if shown).
   - PC:  adb connect TV_IP:PORT        (if a pairing code is shown: adb pair TV_IP:PAIRPORT first)
          adb install -r app-debug.apk
          adb shell am start -n com.minimal.tvlauncher/.MainActivity
   - No PC? An ADB app on your phone (e.g. AtvTools) can run the same commands.

3) MAKE IT THE HOME SCREEN
   adb shell cmd shortcut get-default-launcher       <- write this down, it is your way back
   adb shell cmd package set-home-activity com.minimal.tvlauncher/.MainActivity
   Press Home. If the old screen still opens (common on Android TV):
   adb shell pm disable-user --user 0 com.google.android.tvlauncher
   (use the package name printed above if it is different)
   Then test the Source / HDMI button. If anything breaks, UNDO:
   adb shell pm enable com.google.android.tvlauncher
   adb uninstall com.minimal.tvlauncher

4) SPEED (safe, reversible - set back to 1.0 to undo)
   adb shell settings put global window_animation_scale 0.5
   adb shell settings put global transition_animation_scale 0.5
   adb shell settings put global animator_duration_scale 0.5

5) DEBLOAT - do not guess package names; send these two files to Claude
   adb shell pm list packages -3 > third-party.txt
   adb shell pm list packages -s > system.txt
   Disabling is reversible:  adb shell pm disable-user --user 0 PACKAGE
                             adb shell pm enable PACKAGE
